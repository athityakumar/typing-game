<?php

    $out = "Your Score is = ".$_POST["result"]." <a href='http://eduspectrum.com/mridul/Typeitout/index.php'> Click to play again </>";
    echo $out;
?>